echo var i = 0;
